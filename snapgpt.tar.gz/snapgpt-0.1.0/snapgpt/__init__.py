"""
CodeSnapshot - A tool to create readable snapshots of your codebase.
"""

__version__ = "0.1.0"
